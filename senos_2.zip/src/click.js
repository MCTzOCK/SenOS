// const shdown = require('shutdown-computer');
const {app} = require('electron');
const { hideDialog } = require('./modules/window');

function click_start()
{
    hideDialog();
    windows.setWindow('internal.desktop');
}
