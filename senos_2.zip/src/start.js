wait();
function wait(){
    setTimeout(() => {
        window.location.assign('index.html')
    }, 4000);
}