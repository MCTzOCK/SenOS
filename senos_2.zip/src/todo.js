// This File is a ToDo List and has no relevant code inside.

// TODO: Fix store apps/@mctzock.store/*.*
// TODO: Backend for "kalender"
// TODO: Fix IMG size and position in init.js
// T0D0-FINISHED: Multi Windo Support.
// TODO: Fix CrashReporter