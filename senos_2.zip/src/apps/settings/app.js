const fs = require('fs');
const path = require('path');
const config = JSON.parse(fs.readFileSync(path.join(__dirname, '../../config.json')));
const uConfig = JSON.parse(fs.readFileSync(path.join(__dirname, '../../user.json')));
let section = 'home';

callSettings = function(setting_content)
{
    switch(setting_content) {
        case 'background-image':
            bgImageChoose();
            break;        
        default:
            break;
    }
}

bgImageChoose = function()
{
    console.log('works');
}

console.log('fuckboy')

initSettings = function(){
    document.getElementById('desktop-background-change').setAttribute('src', '../../' + config.appearance.desktop.background);
    
    Array.prototype.forEach.call(document.getElementsByClassName('replacePlaceHolder'), function(el) {
        el.innerText = el.innerText.replace('${senos.system.version}', config.system.version);
        el.innerText = el.innerText.replace('${senos.system.user.current}', uConfig.name);
    });

    Array.prototype.forEach.call(document.getElementsByClassName('checkActivate'), function(el) {
        if(el.id === 'user-password-active'){
            el.checked = uConfig.enabled;
        }
    })
}

changeSection = function(name){
    document.getElementById('section-' + section).classList.add('notVisible');
    document.getElementById('section-' + name).classList.remove('notVisible');
    document.getElementById('section-' + section + '-click').classList.remove('active');
    document.getElementById('section-' + name + '-click').classList.add('active');
    section = name;
}

uPwdChange = function(checked){
    uConfig.enabled = checked;
    fs.writeFileSync(path.join(__dirname, '../../user.json'), JSON.stringify(uConfig));
}