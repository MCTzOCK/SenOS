const content = document.getElementById('content');
const iframe = document.querySelector('iframe');

function search(){
    let url = document.getElementById('url-input').value;
    document.getElementById('content').src = url;
}
function goBack(){
    // document.getElementById('content').src = locs[locs.length--];
    // window.frames[1].frameElement.contentWindow.window.history.back();
    //var iframe = document.querySelector('iframe[id="content"]');
    //ifrm1.document.history.back();
    console.log(frame.title);
}

function goForward(){
    var iframe = document.querySelector('iframe[id="content"]');
    iframe.contentWindow.history.forward();
    // document.getElementById('content').src = locs[locs.length];
    // window.frames[1].frameElement.contentWindow.window.history.forward();
}

// iframe.onload = function(){
//     console.log('123');
//     if(!iframe.src.startsWith('https://') && !iframe.src.startsWith('file:///')){
//         // event.preventDefault();
//         iframe.contentDocument.body.prepend('SSL Certificate error!');
//         iframe.src = "./error/SSL-CERTIFICATE-ERROR-V1.html";
//     }else {
//         iframe.contentDocument.body.prepend('Save Site!')
//     }
// }

// $('iframe').load(function(){
//     $(this).contents().find("body").on('click', function(event) { console.log('deine mutter') });
// });
// const webview = document.querySelector('webview')

// webview.onload = function(){

// }

// webview.onchange = function(){
//     document.getElementById('url-input').value = webview.src;
// }

// iframe.onclick = function() {
//     console.log('123')
//     iframe.contentDocument.body.prepend('123');
// }
// iframe.onsubmit = function() {
//     console.log('123')
//     iframe.contentDocument.body.prepend('123');
// }
// iframe.onchange = function() {
//     console.log('123')
//     iframe.contentDocument.body.prepend('123');
// }
function checkSource(src){
    if(!src.startsWith('https://') && !src.startsWith('file:///')){
        iframe.src = "./error/SSL-CERTIFICATE-ERROR-V1.html";
        // iframe.setAttribute('sandbox', 'allow-forms allow-scripts');
    }else{
        document.getElementById('url-input').value = src;
        // iframe.setAttribute('sandbox', 'allow-forms');
    }
    console.log("[BROWSER] Loadet " + src);
}