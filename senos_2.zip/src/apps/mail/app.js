const mail = require('nodemailer');

var transporter = mail.createTransport