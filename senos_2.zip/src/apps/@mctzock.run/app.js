const fs = require('fs');
const raw_cfg = fs.readFileSync('./src/apps/@mctzock.run/commands.json', 'utf-8');
const cfg = JSON.parse(raw_cfg);

run = function()
{
    let cmd = document.getElementById('cmd').value;
    if(cfg.command.name[cmd] != undefined)
    {
        window.parent.setAndRenderWindow(cfg.command.name[cmd].open);
    }else
    {
        window.parent.setAndRenderWindow(cmd);
    } 
}